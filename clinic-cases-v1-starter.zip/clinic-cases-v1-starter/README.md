# Clinic Cases V1

نظام مستقل لتسجيل وإدارة الحالات التي تزور العيادة. لا علاقة له بنظام الحجوزات السابق.

## V1 Starter
- واجهة عربية RTL متجاوبة للكمبيوتر وأندرويد.
- إضافة حالة جديدة.
- تعديل الحالة.
- بحث بالاسم أو الهاتف.
- منع تكرار نفس رقم الهاتف.
- أرشفة بدل الحذف المباشر.
- PWA manifest + service worker.
- وضع تجريبي محلي إذا لم تتم إضافة إعدادات Firebase.
- Firebase Authentication (Email/Password) وCloud Firestore عند إضافة المتغيرات.
- Firestore rules تمنع أي وصول غير مسجل وتمنع الحذف المباشر.
- GitHub Actions build workflow مع workflow_dispatch.

## Firebase
انسخ `.env.example` إلى `.env` وأضف إعدادات مشروع Firebase. عندها سيطلب التطبيق تسجيل الدخول ويستخدم Firestore بدل التخزين المحلي.

فعّل Email/Password Authentication في Firebase وأنشئ المستخدمين من Firebase Console.

## تشغيل محلي
```bash
npm install
npm run dev
```

## Build
```bash
npm install
npm run build
```

## ملاحظة مهمة
الوضع المحلي للتجربة فقط ولا يحقق مزامنة بين الأجهزة. لا تعتبر النسخة Production قبل تفعيل Firebase Authentication + Firestore ونشر القواعد.
