import './styles.css';
import { firebaseConfigured, auth } from './firebase';
import { signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth';
import { archivePatient, createPatient, listPatients, updatePatient } from './repository';
import type { PatientCase, PatientInput } from './types';

const root = document.querySelector<HTMLDivElement>('#app')!;
let patients: PatientCase[] = [];
let editingId: string | null = null;
let search = '';

function fmtDate(value: string) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? value : new Intl.DateTimeFormat('ar-EG').format(d);
}

function normalizePhone(v: string) {
  return v.replace(/\D/g, '');
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function escapeHtml(s: string) {
  return s.replace(/[&<>'"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c] || c));
}

async function refresh() {
  patients = await listPatients();
  renderApp();
}

function filteredPatients() {
  const q = search.trim().toLowerCase();
  return patients.filter((p) => !p.archived).filter((p) => {
    if (!q) return true;
    return p.fullName.toLowerCase().includes(q) || normalizePhone(p.phone).includes(normalizePhone(q));
  });
}

function renderLogin() {
  root.innerHTML = `
    <main class="login-shell">
      <section class="login-card">
        <div class="brand-mark">+</div>
        <h1>نظام حالات العيادة</h1>
        <p>تسجيل دخول الموظفين</p>
        <form id="login-form" class="stack">
          <label>البريد الإلكتروني<input id="email" type="email" required autocomplete="username"></label>
          <label>كلمة المرور<input id="password" type="password" required autocomplete="current-password"></label>
          <button class="primary" type="submit">تسجيل الدخول</button>
          <div id="login-error" class="error"></div>
        </form>
      </section>
    </main>`;
  document.querySelector<HTMLFormElement>('#login-form')!.addEventListener('submit', async (e) => {
    e.preventDefault();
    const error = document.querySelector<HTMLDivElement>('#login-error')!;
    error.textContent = '';
    try {
      await signInWithEmailAndPassword(
        auth!,
        (document.querySelector<HTMLInputElement>('#email')!).value,
        (document.querySelector<HTMLInputElement>('#password')!).value
      );
    } catch {
      error.textContent = 'تعذر تسجيل الدخول. راجع البريد وكلمة المرور.';
    }
  });
}

function renderApp() {
  const active = patients.filter((p) => !p.archived);
  const todayCount = active.filter((p) => p.visitDate === today()).length;
  const rows = filteredPatients();
  root.innerHTML = `
  <div class="app-shell">
    <aside class="sidebar">
      <div class="brand"><span class="brand-mark small">+</span><div><strong>حالات العيادة</strong><small>Clinic Cases V1</small></div></div>
      <nav>
        <button class="nav active">الرئيسية</button>
        <button class="nav" id="focus-new">تسجيل حالة</button>
        <button class="nav">الحالات</button>
      </nav>
      <div class="sidebar-foot">
        ${firebaseConfigured ? '<button class="nav" id="logout">تسجيل الخروج</button>' : '<small>وضع تجريبي محلي</small>'}
      </div>
    </aside>
    <main class="content">
      <header class="topbar">
        <div><h1>إدارة حالات العيادة</h1><p>تسجيل ومتابعة الحالات داخل العيادة</p></div>
        <button class="primary" id="new-case">+ حالة جديدة</button>
      </header>
      ${firebaseConfigured ? '<div class="status ok">Firebase متصل — البيانات السحابية مفعلة</div>' : '<div class="status warn">وضع تجريبي محلي — البيانات محفوظة على هذا الجهاز فقط. لن نعتبر المزامنة مفعلة قبل ربط Firebase.</div>'}
      <section class="stats">
        <article><span>الحالات اليوم</span><strong>${todayCount}</strong></article>
        <article><span>إجمالي الحالات</span><strong>${active.length}</strong></article>
        <article><span>المؤرشفة</span><strong>${patients.filter((p) => p.archived).length}</strong></article>
      </section>
      <section class="panel" id="form-panel">
        <div class="section-head"><div><h2>${editingId ? 'تعديل الحالة' : 'تسجيل حالة جديدة'}</h2><p>البيانات الأساسية للزيارة الحالية</p></div></div>
        <form id="patient-form" class="form-grid">
          <input id="edit-id" type="hidden" value="${editingId || ''}">
          <label>الاسم بالكامل *<input id="fullName" required maxlength="120"></label>
          <label>رقم الهاتف *<input id="phone" required inputmode="tel" maxlength="20"></label>
          <label>السن<input id="age" type="number" inputmode="numeric" min="0" max="120"></label>
          <label>النوع<select id="gender"><option value="">اختر</option><option>ذكر</option><option>أنثى</option></select></label>
          <label>الطبيب<input id="doctor" maxlength="120"></label>
          <label>التخصص<input id="specialty" maxlength="120"></label>
          <label>تاريخ الزيارة *<input id="visitDate" type="date" required value="${today()}"></label>
          <label class="wide">الشكوى الرئيسية<textarea id="complaint" rows="3" maxlength="1000"></textarea></label>
          <label class="wide">ملاحظات<textarea id="notes" rows="3" maxlength="2000"></textarea></label>
          <div class="actions wide"><button class="primary" type="submit">${editingId ? 'حفظ التعديل' : 'حفظ الحالة'}</button>${editingId ? '<button type="button" class="ghost" id="cancel-edit">إلغاء</button>' : ''}<span id="form-msg"></span></div>
        </form>
      </section>
      <section class="panel">
        <div class="section-head list-head"><div><h2>الحالات</h2><p>${rows.length} حالة ظاهرة</p></div><input id="search" class="search" placeholder="ابحث بالاسم أو رقم الهاتف" value="${escapeHtml(search)}"></div>
        <div class="table-wrap">
          <table><thead><tr><th>الاسم</th><th>الهاتف</th><th>الطبيب</th><th>التخصص</th><th>الزيارة</th><th>إجراءات</th></tr></thead><tbody>
            ${rows.length ? rows.map((p) => `<tr><td>${escapeHtml(p.fullName)}</td><td dir="ltr">${escapeHtml(p.phone)}</td><td>${escapeHtml(p.doctor || '—')}</td><td>${escapeHtml(p.specialty || '—')}</td><td>${fmtDate(p.visitDate)}</td><td><div class="row-actions"><button data-edit="${p.id}">تعديل</button><button data-archive="${p.id}" class="danger-text">أرشفة</button></div></td></tr>`).join('') : '<tr><td colspan="6" class="empty">لا توجد حالات مطابقة</td></tr>'}
          </tbody></table>
        </div>
      </section>
    </main>
  </div>`;

  const form = document.querySelector<HTMLFormElement>('#patient-form')!;
  if (editingId) {
    const p = patients.find((x) => x.id === editingId)!;
    (document.querySelector<HTMLInputElement>('#fullName')!).value = p.fullName;
    (document.querySelector<HTMLInputElement>('#phone')!).value = p.phone;
    (document.querySelector<HTMLInputElement>('#age')!).value = p.age === null ? '' : String(p.age);
    (document.querySelector<HTMLSelectElement>('#gender')!).value = p.gender;
    (document.querySelector<HTMLInputElement>('#doctor')!).value = p.doctor;
    (document.querySelector<HTMLInputElement>('#specialty')!).value = p.specialty;
    (document.querySelector<HTMLInputElement>('#visitDate')!).value = p.visitDate;
    (document.querySelector<HTMLTextAreaElement>('#complaint')!).value = p.complaint;
    (document.querySelector<HTMLTextAreaElement>('#notes')!).value = p.notes;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = document.querySelector<HTMLSpanElement>('#form-msg')!;
    const fullName = (document.querySelector<HTMLInputElement>('#fullName')!).value.trim();
    const phone = (document.querySelector<HTMLInputElement>('#phone')!).value.trim();
    const ageRaw = (document.querySelector<HTMLInputElement>('#age')!).value;
    const duplicate = patients.find((p) => !p.archived && normalizePhone(p.phone) === normalizePhone(phone) && p.id !== editingId);
    if (duplicate) {
      msg.className = 'error';
      msg.textContent = `يوجد ملف مسجل بهذا الرقم باسم: ${duplicate.fullName}`;
      return;
    }
    const input: PatientInput = {
      fullName,
      phone,
      age: ageRaw ? Number(ageRaw) : null,
      gender: (document.querySelector<HTMLSelectElement>('#gender')!).value as PatientInput['gender'],
      doctor: (document.querySelector<HTMLInputElement>('#doctor')!).value.trim(),
      specialty: (document.querySelector<HTMLInputElement>('#specialty')!).value.trim(),
      visitDate: (document.querySelector<HTMLInputElement>('#visitDate')!).value,
      complaint: (document.querySelector<HTMLTextAreaElement>('#complaint')!).value.trim(),
      notes: (document.querySelector<HTMLTextAreaElement>('#notes')!).value.trim()
    };
    try {
      if (editingId) await updatePatient(editingId, input); else await createPatient(input);
      editingId = null;
      await refresh();
    } catch (err) {
      msg.className = 'error';
      msg.textContent = 'تعذر حفظ البيانات. تحقق من الاتصال والإعدادات.';
      console.error(err);
    }
  });

  document.querySelector<HTMLInputElement>('#search')!.addEventListener('input', (e) => {
    search = (e.target as HTMLInputElement).value;
    renderApp();
    const s = document.querySelector<HTMLInputElement>('#search');
    s?.focus(); s?.setSelectionRange(search.length, search.length);
  });

  document.querySelectorAll<HTMLButtonElement>('[data-edit]').forEach((b) => b.addEventListener('click', () => {
    editingId = b.dataset.edit!;
    renderApp();
    document.querySelector('#form-panel')?.scrollIntoView({ behavior: 'smooth' });
  }));
  document.querySelectorAll<HTMLButtonElement>('[data-archive]').forEach((b) => b.addEventListener('click', async () => {
    const p = patients.find((x) => x.id === b.dataset.archive);
    if (!p || !confirm(`أرشفة حالة ${p.fullName}؟ يمكن استعادتها لاحقًا.`)) return;
    await archivePatient(p.id);
    await refresh();
  }));
  document.querySelector<HTMLButtonElement>('#cancel-edit')?.addEventListener('click', () => { editingId = null; renderApp(); });
  ['#new-case','#focus-new'].forEach((sel) => document.querySelector<HTMLButtonElement>(sel)?.addEventListener('click', () => {
    editingId = null; renderApp(); document.querySelector('#form-panel')?.scrollIntoView({ behavior: 'smooth' });
  }));
  document.querySelector<HTMLButtonElement>('#logout')?.addEventListener('click', () => signOut(auth!));
}

async function boot() {
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => undefined);
  if (firebaseConfigured && auth) {
    onAuthStateChanged(auth, async (user) => {
      if (!user) renderLogin(); else { patients = await listPatients(); renderApp(); }
    });
  } else {
    patients = await listPatients();
    renderApp();
  }
}

boot();
