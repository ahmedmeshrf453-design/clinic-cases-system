export type Gender = 'ذكر' | 'أنثى' | '';

export interface PatientCase {
  id: string;
  fullName: string;
  phone: string;
  age: number | null;
  gender: Gender;
  doctor: string;
  specialty: string;
  visitDate: string;
  complaint: string;
  notes: string;
  archived: boolean;
  createdAt: string;
  updatedAt: string;
}

export type PatientInput = Omit<PatientCase, 'id' | 'createdAt' | 'updatedAt' | 'archived'>;
