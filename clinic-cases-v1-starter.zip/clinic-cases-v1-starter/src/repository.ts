import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  updateDoc
} from 'firebase/firestore';
import { db, firebaseConfigured } from './firebase';
import type { PatientCase, PatientInput } from './types';

const LOCAL_KEY = 'clinic-cases-v1-patients';

function nowIso() {
  return new Date().toISOString();
}

function getLocal(): PatientCase[] {
  try {
    return JSON.parse(localStorage.getItem(LOCAL_KEY) || '[]') as PatientCase[];
  } catch {
    return [];
  }
}

function setLocal(rows: PatientCase[]) {
  localStorage.setItem(LOCAL_KEY, JSON.stringify(rows));
}

export async function listPatients(): Promise<PatientCase[]> {
  if (!firebaseConfigured || !db) return getLocal();
  const snap = await getDocs(query(collection(db, 'patients'), orderBy('updatedAt', 'desc')));
  return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<PatientCase, 'id'>) }));
}

export async function createPatient(input: PatientInput): Promise<void> {
  if (!firebaseConfigured || !db) {
    const rows = getLocal();
    const ts = nowIso();
    rows.unshift({ ...input, id: crypto.randomUUID(), archived: false, createdAt: ts, updatedAt: ts });
    setLocal(rows);
    return;
  }
  await addDoc(collection(db, 'patients'), {
    ...input,
    archived: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
}

export async function updatePatient(id: string, input: PatientInput): Promise<void> {
  if (!firebaseConfigured || !db) {
    const rows = getLocal().map((r) => (r.id === id ? { ...r, ...input, updatedAt: nowIso() } : r));
    setLocal(rows);
    return;
  }
  await updateDoc(doc(db, 'patients', id), { ...input, updatedAt: serverTimestamp() });
}

export async function archivePatient(id: string): Promise<void> {
  if (!firebaseConfigured || !db) {
    const rows = getLocal().map((r) => (r.id === id ? { ...r, archived: true, updatedAt: nowIso() } : r));
    setLocal(rows);
    return;
  }
  await updateDoc(doc(db, 'patients', id), { archived: true, updatedAt: serverTimestamp() });
}

export async function hardDeleteLocalDemo(id: string): Promise<void> {
  if (firebaseConfigured && db) {
    await deleteDoc(doc(db, 'patients', id));
    return;
  }
  setLocal(getLocal().filter((r) => r.id !== id));
}
